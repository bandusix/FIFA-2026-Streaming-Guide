import asyncio
import re
from playwright.async_api import async_playwright

# 选取几个具有代表性的官方转播商作为测试对象
OFFICIAL_SOURCES = [
    "https://abema.tv/",              # 日本 ABEMA
    "https://www.miguvideo.com/",     # 中国 咪咕视频
    "https://www.foxsports.com/soccer", # 美国 FOX Sports
    "https://www.bbc.co.uk/iplayer",  # 英国 BBC
    "https://www.tf1.fr/"             # 法国 TF1
]

# 测试用：当天的一些参赛队伍关键字
TEAM_KEYWORDS = ["spain", "cape verde", "belgium", "egypt", "saudi", "uruguay"]

async def fetch_links_from_site(page, url):
    try:
        print(f"[{url}] Navigating...")
        # 官方网站加载可能较慢，且有各类弹窗
        await page.goto(url, wait_until="domcontentloaded", timeout=25000)
        await asyncio.sleep(5) # 给官方网站的动态框架（React/Vue）足够的渲染时间
        
        # 尝试滚动页面触发懒加载
        await page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        await asyncio.sleep(2)
        
        links = await page.eval_on_selector_all("a", "elements => elements.map(e => ({href: e.href, text: e.innerText}))")
        return [l for l in links if l.get("href") and l.get("href").startswith("http")]
    except Exception as e:
        print(f"[{url}] Error: {e}")
        return []

async def main():
    print("=== Official Sources Crawler Test Environment ===\n")
    
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        # 模拟普通用户，部分官方源对 UA 有校验
        context = await browser.new_context(
            user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
            viewport={"width": 1280, "height": 720}
        )
        
        for url in OFFICIAL_SOURCES:
            page = await context.new_page()
            links = await fetch_links_from_site(page, url)
            await page.close()
            
            print(f"\n--- Results for {url} ---")
            found_matches = False
            
            for link in links:
                href = link["href"].lower()
                text = link["text"].lower()
                combined = f"{href} {text}"
                
                # 简单过滤：检查是否包含测试队伍的名字，或者是 live/sports/fifa 相关的链接
                match_found = any(kw in combined for kw in TEAM_KEYWORDS)
                
                if match_found or "fifa" in combined or "world-cup" in combined or "worldcup" in combined:
                    print(f"  [Match Link Candidate] {link['text'].replace('\n', ' ').strip()} -> {link['href']}")
                    found_matches = True
            
            if not found_matches:
                print("  No match-specific deep links found on the homepage.")
                print("  (Reason: Official sites often hide streams behind 'Sports' tabs, paywalls, geo-blocks, or specific event sub-pages.)")
                
        await browser.close()

if __name__ == "__main__":
    asyncio.run(main())