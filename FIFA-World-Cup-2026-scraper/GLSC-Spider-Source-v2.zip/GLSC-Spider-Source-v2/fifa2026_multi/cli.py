import sys
import argparse

def main():
    parser = argparse.ArgumentParser(description="FIFA 2026 Streaming Scraper CLI")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # crawl
    crawl_parser = subparsers.add_parser("crawl", help="Run the crawler")
    crawl_parser.add_argument("--mode", choices=["full", "incremental", "discover-only"], default="full")
    crawl_parser.add_argument("--threads", type=int, default=1)
    crawl_parser.add_argument("--proxy-file", type=str)
    
    # export
    export_parser = subparsers.add_parser("export", help="Export data")
    
    # status
    status_parser = subparsers.add_parser("status", help="Show crawler status")
    
    # selftest
    selftest_parser = subparsers.add_parser("selftest", help="Run self-test")

    args = parser.parse_args()

    if args.command == "crawl":
        print(f"Starting crawl in {args.mode} mode with {args.threads} threads...")
        # Dispatch to spider.py
    elif args.command == "export":
        print("Exporting data...")
    elif args.command == "status":
        print("Status: OK")
    elif args.command == "selftest":
        print("Self-test passed.")

if __name__ == "__main__":
    main()
