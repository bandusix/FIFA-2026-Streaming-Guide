# FIFA World Cup 2026 — Multilingual Live Schedule

A single-page, dependency-free web app that shows the full **FIFA World Cup 2026**
fixture list (104 matches), localized to each visitor's **language**, **time zone**,
and **country** (which drives both the UI language and the official broadcast sources).

> **Status:** working prototype, verified in-browser. Schedule data is partially
> verified against official sources (see [`UPDATE_LOG.md`](UPDATE_LOG.md)); broadcast
> sources are official rights-holders that still need final per-country verification.
> See **Open tasks** in [`HANDOFF.md`](HANDOFF.md) before continuing development.

---

## ✨ Features

| Feature | Notes |
|---|---|
| **104 matches** | Group stage (A–L) + full knockout bracket (R32 → Final). |
| **12 UI languages** | English, Português, Español, 简体中文, 繁體中文, Français, Italiano, Русский, Deutsch, हिन्दी, Bahasa Indonesia, Türkçe. |
| **Auto-localized team names** | All 48 nations translated automatically via `Intl.DisplayNames` (no manual translation table). |
| **Local-time conversion** | Kickoffs stored as US-Eastern and converted to the visitor's own time zone via `Intl.DateTimeFormat`. |
| **Country-based delivery** | Visitor country (IP geo) selects the default UI language **and** the broadcast sources. Manual override available and persisted. |
| **Per-country broadcast sources** | 2 official rights-holders per country (62 countries). Official/licensed only — no piracy. |
| **Endonym country picker** | Each country shown in its own script (日本, السعودية, Россия…), independent of UI language. |
| **Live / Full-time status** | Auto-refreshes every minute; "Today/Tomorrow" date grouping; team search; Upcoming/All filter. |
| **Responsive dark UI** | Works on mobile and desktop. |
| **Daily auto-verification** | A scheduled agent re-checks the schedule against official FIFA data each day (see [`RUNBOOK.md`](RUNBOOK.md)). |

---

## 🏃 Run it

No build step, no dependencies. Either:

```bash
# Option A — static server (recommended; matches .claude/launch.json)
python3 -m http.server 8765
# then open http://localhost:8765

# Option B — just open the file
open index.html        # works too: data files load via <script src>, not fetch
```

Network is used at runtime for: flag images (`flagcdn.com`) and IP geolocation
(`ipquery.io` + fallbacks). Everything else is local.

---

## 📁 File structure

```
FIFA2026/
├── index.html          # The entire app: markup + CSS + JS (UI, i18n, timezone, geo, render)
├── matches.js          # FIXTURE DATA — window.WC_MATCHES + window.WC_LAST_VERIFIED  ← daily routine edits this
├── sources.js          # BROADCAST SOURCES — window.WC_SOURCES (per country)
├── README.md           # This file
├── HANDOFF.md          # Technical deep-dive + conventions + open tasks (READ THIS to continue dev)
├── RUNBOOK.md          # Daily schedule-verification procedure (for the automated agent)
├── UPDATE_LOG.md       # Append-only change history (newest on top)
├── CONVERSATION_LOG.md # How the project evolved — original requirements & decisions
└── .claude/
    └── launch.json     # Local preview server config (python http.server :8765)
```

**Separation of concerns:** all data lives in `matches.js` (schedule) and `sources.js`
(broadcasters). `index.html` holds only logic + presentation. Never inline data into
`index.html`.

---

## 🧩 Data models

### `matches.js` — `window.WC_MATCHES` (array of 104)

```js
// Group-stage match
{ n:37, g:"G", d:"2026-06-15T21:00:00-04:00", c:"Inglewood", h:"ir", a:"nz" }
// Finished match adds a score
{ n:1,  g:"A", d:"2026-06-11T16:00:00-04:00", c:"Mexico City", h:"mx", a:"za", s:[2,0] }
// Knockout match — teams are placeholder slots until the bracket resolves
{ n:73, r:"r32", d:"2026-06-28T15:00:00-04:00", c:"Inglewood", h:R("A"), a:R("B") }
```

| Field | Meaning |
|---|---|
| `n` | Match number 1–104 (unique). |
| `g` | Group letter `"A".."L"` (group stage) **or** `r` = round key (`r32,r16,qf,sf,tp,final`). |
| `d` | Kickoff as **US-Eastern (EDT, UTC-4) wall-clock** with `-04:00` suffix = the true instant. |
| `c` | Host city (maps to a stadium in `V{}` inside `index.html`). |
| `h` / `a` | Home/away team. Group stage = ISO alpha-2 flag code (`"br"`, `"gb-eng"`). Knockout = slot object via `W("A")` / `R("B")` / `TH("A/B/C/D/F")`, or omit for TBD. |
| `s` | `[home, away]` score, only for finished matches. |

`window.WC_LAST_VERIFIED` = `"YYYY-MM-DD"` of the last verification (shown in the footer).

### `sources.js` — `window.WC_SOURCES` (keyed by country)

```js
window.WC_SOURCES = {
  "US": [ {name:"FOX Sports", url:"https://...", lang:"en"},
          {name:"Telemundo",  url:"https://...", lang:"es"} ],
  // ...
};
```

| Field | Meaning |
|---|---|
| `name` | Broadcaster display name. |
| `url` | Link to the broadcaster's **official** live player / streaming page. |
| `lang` | *(optional)* commentary language tag, shown as a small chip. |
| `matchNo` | *(optional)* restrict a source to one match; omit = applies to all matches. |

> ⚖️ **Only official/licensed rights-holders.** Unauthorized "free stream" aggregators
> are intentionally excluded (illegal redistribution + malware risk).

---

## 🌍 How localization works

- **UI strings** → manual dictionary `T` in `index.html` (12 languages).
- **Team / country names in match cards** → `Intl.DisplayNames` in the active UI language
  (with manual overrides for `gb-eng`, `gb-sct`, `cd`).
- **Country picker labels** → **endonyms** via `Intl.DisplayNames` in each country's own
  locale (`COUNTRY_LOCALE` map) — independent of UI language.
- **Language picker labels** → native autonyms, hardcoded in `LANGS`.
- **Country → default language** → `COUNTRY_LANG` map (manual language choice overrides).
- **IP geolocation** → `ipquery.io` (primary) → `api.ip.sb` → `geojs.io` → `country.is` →
  `ipapi.co` fallback chain; timezone/locale as provisional guess until IP resolves.

See [`HANDOFF.md`](HANDOFF.md) for the full function-level walkthrough.

---

## 🔧 Common edits

- **Fix a kickoff time** → edit the match's `d` in `matches.js` (keep the `-04:00` form;
  conversion rules in `RUNBOOK.md`).
- **Add/replace a broadcaster** → edit `sources.js`.
- **Add a UI language** → add the locale to `LANGS` + a column to every key in `T`.
- **Add a country** → add it to `COUNTRY_LANG` (+ `COUNTRY_LOCALE` for its endonym) and,
  optionally, `sources.js`.
- **Fill knockout teams** → replace `W()/R()/TH()` slots with ISO codes once known.

---

## ⚠️ Known limitations

1. **Schedule accuracy** — original times came from ESPN (unreliable for non-Eastern
   venues); partially corrected against Wikipedia. **Source of truth going forward is the
   official FIFA JSON API** (see RUNBOOK). Some single-source discrepancies remain open
   (tracked in `UPDATE_LOG.md`).
2. **Broadcast rights** — listed broadcasters are best-known official holders; exact 2026
   per-country assignments + deep-link URLs must be confirmed against FIFA's official
   "Where to Watch" before launch.
3. **Knockout bracket** — teams are placeholders until groups finalize.
4. **IP geolocation** — free public APIs (rate limits / occasional blocks); the fallback
   chain mitigates this, and a manual country picker is always available.

Full context and next steps: **[`HANDOFF.md`](HANDOFF.md)**.
