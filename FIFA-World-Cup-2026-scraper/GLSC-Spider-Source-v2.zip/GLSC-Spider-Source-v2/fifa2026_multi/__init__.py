"""
fifa2026_multi package initialization.
"""
