/* ============================================================
   FIFA World Cup 2026 — FIXTURE DATA  (auto-corrected daily)
   ------------------------------------------------------------
   This file is the SINGLE SOURCE OF TRUTH for match data and is
   the ONLY file the daily verification routine should edit.
   See RUNBOOK.md for the update procedure and UPDATE_LOG.md for
   the change history.

   Time convention: every kickoff is stored as the US Eastern
   (EDT, UTC-4) wall-clock with the "-04:00" suffix, i.e. the
   true instant. index.html converts it to each visitor's zone.

   Match object shape:
     {n, g|r, d, c, h, a, s?}
       n = match number (1-104)
       g = group letter "A".."L"   OR   r = round key
           (r32, r16, qf, sf, tp, final)
       d = ISO datetime with -04:00 offset
       c = host city (maps to a stadium in index.html V{})
       h = home team   a = away team
           - group stage: ISO flag code (e.g. "br", "gb-eng")
           - knockout:    slot object via W()/R()/TH(), or omit for TBD
       s = [home, away] score  (only for finished matches)
   ============================================================ */

// ISO date (YYYY-MM-DD) of the last successful verification against official sources.
window.WC_LAST_VERIFIED = "2026-06-15";

// Knockout placeholder builders + US Eastern offset constant.
const W = g => ({ k: "winner", g });
const R = g => ({ k: "runner", g });
const TH = g => ({ k: "third", g });
const ET = "-04:00";

window.WC_MATCHES = [
 // GROUP A
 {n:1,g:"A",d:"2026-06-11T16:00:00"+ET,c:"Mexico City",h:"mx",a:"za",s:[2,0]},
 {n:2,g:"A",d:"2026-06-11T19:00:00"+ET,c:"Zapopan",h:"kr",a:"cz",s:[2,1]},
 {n:3,g:"A",d:"2026-06-18T12:00:00"+ET,c:"Atlanta",h:"cz",a:"za"},
 {n:4,g:"A",d:"2026-06-18T21:00:00"+ET,c:"Zapopan",h:"mx",a:"kr"},
 {n:5,g:"A",d:"2026-06-24T21:00:00"+ET,c:"Mexico City",h:"cz",a:"mx"},
 {n:6,g:"A",d:"2026-06-24T21:00:00"+ET,c:"Guadalupe",h:"za",a:"kr"},
 // GROUP B
 {n:7,g:"B",d:"2026-06-12T20:00:00"+ET,c:"Toronto",h:"ca",a:"ba",s:[1,1]},
 {n:8,g:"B",d:"2026-06-12T15:00:00"+ET,c:"Santa Clara",h:"qa",a:"ch",s:[1,1]},
 {n:9,g:"B",d:"2026-06-18T15:00:00"+ET,c:"Inglewood",h:"ch",a:"ba"},
 {n:10,g:"B",d:"2026-06-18T18:00:00"+ET,c:"Vancouver",h:"ca",a:"qa"},
 {n:11,g:"B",d:"2026-06-24T15:00:00"+ET,c:"Vancouver",h:"ch",a:"ca"},
 {n:12,g:"B",d:"2026-06-24T15:00:00"+ET,c:"Seattle",h:"ba",a:"qa"},
 // GROUP C
 {n:13,g:"C",d:"2026-06-13T17:00:00"+ET,c:"Foxborough",h:"ht",a:"gb-sct",s:[0,1]},
 {n:14,g:"C",d:"2026-06-13T20:00:00"+ET,c:"East Rutherford",h:"br",a:"ma",s:[1,1]},
 {n:15,g:"C",d:"2026-06-19T18:00:00"+ET,c:"Foxborough",h:"gb-sct",a:"ma"},
 {n:16,g:"C",d:"2026-06-19T21:00:00"+ET,c:"Philadelphia",h:"br",a:"ht"},
 {n:17,g:"C",d:"2026-06-24T18:00:00"+ET,c:"Miami Gardens",h:"gb-sct",a:"br"},
 {n:18,g:"C",d:"2026-06-24T18:00:00"+ET,c:"Atlanta",h:"ma",a:"ht"},
 // GROUP D
 {n:19,g:"D",d:"2026-06-12T21:00:00"+ET,c:"Inglewood",h:"us",a:"py",s:[4,1]},
 {n:20,g:"D",d:"2026-06-14T00:00:00"+ET,c:"Vancouver",h:"au",a:"tr",s:[2,0]},
 {n:21,g:"D",d:"2026-06-19T15:00:00"+ET,c:"Seattle",h:"us",a:"au"},
 {n:22,g:"D",d:"2026-06-19T23:00:00"+ET,c:"Santa Clara",h:"tr",a:"py"},
 {n:23,g:"D",d:"2026-06-25T22:00:00"+ET,c:"Inglewood",h:"tr",a:"us"},
 {n:24,g:"D",d:"2026-06-25T22:00:00"+ET,c:"Santa Clara",h:"py",a:"au"},
 // GROUP E
 {n:25,g:"E",d:"2026-06-14T13:00:00"+ET,c:"Houston",h:"de",a:"cw",s:[7,1]},
 {n:26,g:"E",d:"2026-06-14T20:00:00"+ET,c:"Philadelphia",h:"ci",a:"ec",s:[1,0]},
 {n:27,g:"E",d:"2026-06-20T16:00:00"+ET,c:"Toronto",h:"de",a:"ci"},
 {n:28,g:"E",d:"2026-06-20T20:00:00"+ET,c:"Kansas City",h:"ec",a:"cw"},
 {n:29,g:"E",d:"2026-06-25T16:00:00"+ET,c:"East Rutherford",h:"ec",a:"de"},
 {n:30,g:"E",d:"2026-06-25T16:00:00"+ET,c:"Philadelphia",h:"cw",a:"ci"},
 // GROUP F
 {n:31,g:"F",d:"2026-06-14T19:00:00"+ET,c:"Arlington",h:"nl",a:"jp",s:[2,2]},
 {n:32,g:"F",d:"2026-06-14T22:00:00"+ET,c:"Guadalupe",h:"se",a:"tn"},
 {n:33,g:"F",d:"2026-06-20T13:00:00"+ET,c:"Houston",h:"nl",a:"se"},
 {n:34,g:"F",d:"2026-06-21T00:00:00"+ET,c:"Guadalupe",h:"tn",a:"jp"},
 {n:35,g:"F",d:"2026-06-25T19:00:00"+ET,c:"Arlington",h:"jp",a:"se"},
 {n:36,g:"F",d:"2026-06-25T19:00:00"+ET,c:"Kansas City",h:"tn",a:"nl"},
 // GROUP G  (June 15 times corrected 2026-06-15 vs Wikipedia/FIFA)
 {n:37,g:"G",d:"2026-06-15T15:00:00"+ET,c:"Seattle",h:"be",a:"eg"},
 {n:38,g:"G",d:"2026-06-15T21:00:00"+ET,c:"Inglewood",h:"ir",a:"nz"},
 {n:39,g:"G",d:"2026-06-21T15:00:00"+ET,c:"Inglewood",h:"be",a:"ir"},
 {n:40,g:"G",d:"2026-06-21T21:00:00"+ET,c:"Vancouver",h:"nz",a:"eg"},
 {n:41,g:"G",d:"2026-06-26T23:00:00"+ET,c:"Seattle",h:"eg",a:"ir"},
 {n:42,g:"G",d:"2026-06-26T23:00:00"+ET,c:"Vancouver",h:"nz",a:"be"},
 // GROUP H
 {n:43,g:"H",d:"2026-06-15T13:00:00"+ET,c:"Atlanta",h:"es",a:"cv"},
 {n:44,g:"H",d:"2026-06-15T18:00:00"+ET,c:"Miami Gardens",h:"sa",a:"uy"},
 {n:45,g:"H",d:"2026-06-21T12:00:00"+ET,c:"Atlanta",h:"es",a:"sa"},
 {n:46,g:"H",d:"2026-06-21T18:00:00"+ET,c:"Miami Gardens",h:"uy",a:"cv"},
 {n:47,g:"H",d:"2026-06-26T20:00:00"+ET,c:"Houston",h:"cv",a:"sa"},
 {n:48,g:"H",d:"2026-06-26T20:00:00"+ET,c:"Zapopan",h:"uy",a:"es"},
 // GROUP I
 {n:49,g:"I",d:"2026-06-16T15:00:00"+ET,c:"East Rutherford",h:"fr",a:"sn"},
 {n:50,g:"I",d:"2026-06-16T18:00:00"+ET,c:"Foxborough",h:"iq",a:"no"},
 {n:51,g:"I",d:"2026-06-22T17:00:00"+ET,c:"Philadelphia",h:"fr",a:"iq"},
 {n:52,g:"I",d:"2026-06-22T20:00:00"+ET,c:"East Rutherford",h:"no",a:"sn"},
 {n:53,g:"I",d:"2026-06-26T15:00:00"+ET,c:"Foxborough",h:"no",a:"fr"},
 {n:54,g:"I",d:"2026-06-26T15:00:00"+ET,c:"Toronto",h:"sn",a:"iq"},
 // GROUP J
 {n:55,g:"J",d:"2026-06-16T21:00:00"+ET,c:"Kansas City",h:"ar",a:"dz"},
 {n:56,g:"J",d:"2026-06-17T00:00:00"+ET,c:"Santa Clara",h:"at",a:"jo"},
 {n:57,g:"J",d:"2026-06-22T13:00:00"+ET,c:"Arlington",h:"ar",a:"at"},
 {n:58,g:"J",d:"2026-06-22T23:00:00"+ET,c:"Santa Clara",h:"jo",a:"dz"},
 {n:59,g:"J",d:"2026-06-27T22:00:00"+ET,c:"Kansas City",h:"dz",a:"at"},
 {n:60,g:"J",d:"2026-06-27T22:00:00"+ET,c:"Arlington",h:"jo",a:"ar"},
 // GROUP K
 {n:61,g:"K",d:"2026-06-17T13:00:00"+ET,c:"Houston",h:"pt",a:"cd"},
 {n:62,g:"K",d:"2026-06-17T22:00:00"+ET,c:"Mexico City",h:"uz",a:"co"},
 {n:63,g:"K",d:"2026-06-23T13:00:00"+ET,c:"Houston",h:"pt",a:"uz"},
 {n:64,g:"K",d:"2026-06-23T22:00:00"+ET,c:"Zapopan",h:"co",a:"cd"},
 {n:65,g:"K",d:"2026-06-27T19:30:00"+ET,c:"Miami Gardens",h:"co",a:"pt"},
 {n:66,g:"K",d:"2026-06-27T19:30:00"+ET,c:"Atlanta",h:"cd",a:"uz"},
 // GROUP L
 {n:67,g:"L",d:"2026-06-17T16:00:00"+ET,c:"Arlington",h:"gb-eng",a:"hr"},
 {n:68,g:"L",d:"2026-06-17T19:00:00"+ET,c:"Toronto",h:"gh",a:"pa"},
 {n:69,g:"L",d:"2026-06-23T16:00:00"+ET,c:"Foxborough",h:"gb-eng",a:"gh"},
 {n:70,g:"L",d:"2026-06-23T19:00:00"+ET,c:"Toronto",h:"pa",a:"hr"},
 {n:71,g:"L",d:"2026-06-27T17:00:00"+ET,c:"East Rutherford",h:"pa",a:"gb-eng"},
 {n:72,g:"L",d:"2026-06-27T17:00:00"+ET,c:"Philadelphia",h:"hr",a:"gh"},
 // ROUND OF 32
 {n:73,r:"r32",d:"2026-06-28T15:00:00"+ET,c:"Inglewood",h:R("A"),a:R("B")},
 {n:74,r:"r32",d:"2026-06-29T13:00:00"+ET,c:"Houston",h:W("C"),a:R("F")},
 {n:75,r:"r32",d:"2026-06-29T16:30:00"+ET,c:"Foxborough",h:W("E"),a:TH("A/B/C/D/F")},
 {n:76,r:"r32",d:"2026-06-29T21:00:00"+ET,c:"Guadalupe",h:W("F"),a:R("C")},
 {n:77,r:"r32",d:"2026-06-30T13:00:00"+ET,c:"Arlington",h:R("E"),a:R("I")},
 {n:78,r:"r32",d:"2026-06-30T17:00:00"+ET,c:"East Rutherford",h:W("I"),a:TH("C/D/F/G/H")},
 {n:79,r:"r32",d:"2026-06-30T21:00:00"+ET,c:"Mexico City",h:W("A"),a:TH("C/E/F/H/I")},
 {n:80,r:"r32",d:"2026-07-01T12:00:00"+ET,c:"Atlanta",h:W("L"),a:TH("E/H/I/J/K")},
 {n:81,r:"r32",d:"2026-07-01T16:00:00"+ET,c:"Seattle",h:W("G"),a:TH("A/E/H/I/J")},
 {n:82,r:"r32",d:"2026-07-01T20:00:00"+ET,c:"Santa Clara",h:W("D"),a:TH("B/E/F/I/J")},
 {n:83,r:"r32",d:"2026-07-02T15:00:00"+ET,c:"Inglewood",h:W("H"),a:R("J")},
 {n:84,r:"r32",d:"2026-07-02T19:00:00"+ET,c:"Toronto",h:R("K"),a:R("L")},
 {n:85,r:"r32",d:"2026-07-02T23:00:00"+ET,c:"Vancouver",h:W("B"),a:TH("E/F/G/I/J")},
 {n:86,r:"r32",d:"2026-07-03T14:00:00"+ET,c:"Arlington",h:R("D"),a:R("G")},
 {n:87,r:"r32",d:"2026-07-03T18:00:00"+ET,c:"Miami Gardens",h:W("J"),a:R("H")},
 {n:88,r:"r32",d:"2026-07-03T21:30:00"+ET,c:"Kansas City",h:W("K"),a:TH("D/E/I/J/L")},
 // ROUND OF 16
 {n:89,r:"r16",d:"2026-07-04T13:00:00"+ET,c:"Houston"},
 {n:90,r:"r16",d:"2026-07-04T17:00:00"+ET,c:"Philadelphia"},
 {n:91,r:"r16",d:"2026-07-05T16:00:00"+ET,c:"East Rutherford"},
 {n:92,r:"r16",d:"2026-07-05T20:00:00"+ET,c:"Mexico City"},
 {n:93,r:"r16",d:"2026-07-06T15:00:00"+ET,c:"Arlington"},
 {n:94,r:"r16",d:"2026-07-06T17:00:00"+ET,c:"Seattle"},
 {n:95,r:"r16",d:"2026-07-07T12:00:00"+ET,c:"Atlanta"},
 {n:96,r:"r16",d:"2026-07-07T16:00:00"+ET,c:"Vancouver"},
 // QUARTER-FINALS
 {n:97,r:"qf",d:"2026-07-09T16:00:00"+ET,c:"Foxborough"},
 {n:98,r:"qf",d:"2026-07-10T15:00:00"+ET,c:"Inglewood"},
 {n:99,r:"qf",d:"2026-07-11T17:00:00"+ET,c:"Miami Gardens"},
 {n:100,r:"qf",d:"2026-07-11T21:00:00"+ET,c:"Kansas City"},
 // SEMI-FINALS
 {n:101,r:"sf",d:"2026-07-14T15:00:00"+ET,c:"Arlington"},
 {n:102,r:"sf",d:"2026-07-15T15:00:00"+ET,c:"Atlanta"},
 // THIRD PLACE
 {n:103,r:"tp",d:"2026-07-18T17:00:00"+ET,c:"Miami Gardens"},
 // FINAL
 {n:104,r:"final",d:"2026-07-19T15:00:00"+ET,c:"East Rutherford"}
];
