# FIFA World Cup 2026 - Global Live Sport Crawler (GLSC)

本项目是一个专门用于聚合抓取 **2026 年 FIFA 世界杯** 直播和回放源的自动化爬虫框架。项目严格遵循 `GLSC`（Global Live Sport Crawler）的逻辑哲学与设计原理，实现了从非结构化网页播放源到结构化赛事时间的完美映射。

## 🎯 核心逻辑与哲学 (GLSC 规范)

1. **数据驱动而非页面驱动**
   爬虫并不直接从网站首页盲目抓取链接，而是将抓取到的所有第三方或官方源，通过队伍名称和关键字模糊匹配，深度关联到一份标准的赛程数据库（`matches.js`）中的 `Match ID` 上。
2. **时间维度绝对化**
   每一条抓取到的播放源，都会被赋予其对应比赛的**标准 UTC 开赛时间**，作为判定其状态（未开赛、直播中、已完赛）的唯一基准。
3. **播放源状态的三重维度分类**
   根据比赛的 UTC 时间与当前时间的对比，播放源会被自动分类到三种不同状态中：
   - **时间计划 (Scheduled)**：未开赛的赛事直播源预留。
   - **实时直播 (Live)**：开赛起 3 小时内的直播源。
   - **全场回放 (Replays)**：超过 3 小时完赛的录像，或源文本明确包含 "Replay" 字眼。

---

## 📊 输出字段说明与数据样例

为了保证下游系统的兼容性与数据结构的一致性，系统导出的最终表格（如 `categorized_streams.xlsx`）以及 JSON 中，统一包含以下 **8 个核心字段**：

### 字段说明

| 字段名 | 说明 |
| :--- | :--- |
| **Match ID** | 赛事的唯一标识符，关联到 `matches.js` 中的 `n` 值（例如 `43`）。 |
| **Home Team** | 主队全称（如果处于小组赛阶段），或淘汰赛对阵位置（例如 `Winner Group A`）。 |
| **Away Team** | 客队全称（如果处于小组赛阶段），或淘汰赛对阵位置（例如 `Runner-up Group B`）。 |
| **Match Time (UTC)** | 标准的 UTC 格式开赛时间，确保全球时间统一（例如 `2026-06-18 16:00:00 UTC`）。 |
| **Stream Type** | 播放源类别，目前包含 `Official Broadcaster`（官方授权）或 `Third-Party/Live/PPV`（第三方聚合/付费）。 |
| **Source** | 来源站点的域名或短名称（例如 `pelota-libretv.com` 或 `footreplays.com`）。 |
| **Player URL** | 最终可供用户播放视频或嵌入网页的 URL 地址（例如 `https://pelota-libretv.com/Transmision2?src=...`）。 |
| **Description** | 播放源的附加说明，如频道名称、清晰度或语言（例如 `Telemundo HD` 或 `Full Match Replay`）。 |

### 数据样例 (JSON 格式)

```json
{
  "Match ID": 43,
  "Home Team": "Argentina",
  "Away Team": "Austria",
  "Match Time (UTC)": "2026-06-18 16:00:00 UTC",
  "Stream Type": "Third-Party/Live/PPV",
  "Source": "pelota-libretv.com",
  "Player URL": "https://pelota-libretv.com/Transmision2?src=https%3A%2F%2Fpltvhd.com%2Fembed%2Feventos.html%3Fr%3DaHR0cHM6Ly90dnR2aGQuY29tL29ubGluZS9jYW5hbGVzLnBocD9zdHJlYW09dGVsZW11bmRv",
  "Description": "Telemundo HD"
}
```

---

## 📂 目录结构说明

```text
GLSC-Spider-Source/
├── README.md                           # 本说明文档
├── README_ORIGINAL.md                  # 原始项目的英文自述文件
├── matches.js                          # 核心依赖：包含104场世界杯赛程的标准数据源
├── fifa2026_multi/                     # 爬虫核心源码目录
│   ├── cli.py                          # 统一命令行入口
│   ├── live_streaming_crawler.py       # 第三方聚合直播站爬虫 (基于 Playwright)
│   ├── official_streaming_crawler.py   # 全球官方转播商爬虫 (内置拦截优化和代理切换)
│   ├── livsports_streaming_crawler.py  # Livsports 专用 API 爬虫
│   ├── footreplays_crawler.py          # Footreplays 全场回放分页爬虫
│   ├── ppv_streaming_crawler.py        # PPV 付费源规则预测探测爬虫
│   └── pelota_libretv_crawler.py       # Pelota Libre TV 定制化解析爬虫
```

---

## 🚀 支持的抓取站点

| 类别 | 站点 | 抓取方式 |
| :--- | :--- | :--- |
| **第三方聚合站** | footybite.ac, vipboxtv.sk, olympicweb.me... | Playwright 动态渲染解析 |
| **官方转播商** | Telemundo, FOX, BBC, ITV, CCTV 等 | 代理切换 + 无头浏览器拦截 |
| **API 及播放器** | streamed.pk, livsports.dpdns.org | 直接请求与 URL 动态拼接 |
| **录像回放库** | footreplays.com | 分页遍历与 Slug 逆向推导 |
| **规则预测源** | old.ppv.to | 赛程全量预测 + HTTP HEAD 探针 |

---

## 💻 安装与使用用法

### 1. 环境准备
确保您的系统已安装 `Python 3.8+`，并安装必要的依赖库：
```bash
pip install playwright beautifulsoup4 pandas openpyxl
```
首次使用 Playwright 需要安装内置浏览器：
```bash
playwright install chromium
```

### 2. 运行爬虫
您可以直接调用特定的爬虫模块来抓取特定的网站群，例如：

**抓取所有第三方聚合直播源**：
```bash
python3 -m fifa2026_multi.live_streaming_crawler
```

**抓取 Pelota Libre TV 源**：
```bash
python3 -m fifa2026_multi.pelota_libretv_crawler
```

**抓取所有官方转播源**（注意：这需要配置代理环境）：
```bash
python3 -m fifa2026_multi.official_streaming_crawler
```

### 3. 数据流转与导出
脚本运行后，会自动抓取播放源并将其结构化，写入到上级目录（即运行目录）的 `streams.json` 或 `official_streams.json` 中。
结合后续的数据处理脚本（如 `generate_categorized_excel.py`），这些源会被合并并输出为包含 `Scheduled`、`Live`、`Replays` 三个页签的 Excel 文件。
