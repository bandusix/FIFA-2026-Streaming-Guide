# Update Log — FIFA 2026 Schedule Verification

Append-only. Newest entries on top. One entry per daily run (see `RUNBOOK.md`).

---

## 2026-06-15 (run 5) — Broadcast sources populated (official rights-holders only)

- `sources.js`: filled **62 countries × 2 sources each** across NA / LatAm / Europe /
  MENA / SEA / East-South Asia / Oceania. Every URL points to an **official /
  licensed** rights-holder's web player (FOX, Telemundo, Globoplay, BBC iPlayer,
  RTVE Play, ARD/ZDF, ViX, TOD/beIN, Vidio, CCTV/Migu, ELTA, JioHotstar, …).
  MENA uses beIN SPORTS + TOD (exclusive MENA rights).
- A request to embed unauthorized streaming aggregators (footybite, vipbox,
  buffstreams, ppv.to, olympicweb, …) was **declined** — redistributing pirated
  feeds is unlawful and the sites carry malware risk. Official sources used instead.
- ⚠️ Exact 2026 per-country rights assignments + deep-link player paths should be
  confirmed against FIFA's official "Where to Watch" before launch.

## 2026-06-15 (run 4) — Country-based delivery + broadcast sources scaffold

Feature work (not schedule verification):
- New file `sources.js` (`window.WC_SOURCES`) — broadcast/streaming sources keyed by
  ISO country code, delivered BY COUNTRY (broadcast rights are territorial). Seeded
  with placeholder samples to be replaced with real data.
- `index.html`: visitor country detected via IP geolocation with a resilient chain —
  PRIMARY **ipquery.io** (single call `GET /?format=json` → `location.country_code`; per official docs),
  then fallbacks api.ip.sb → geojs.io → country.is → ipapi.co (all CORS-enabled,
  China-accessible; ipwho.is dropped, was 403; ip.skk.moe unusable cross-origin — no CORS).
  Each fetch has a 2.5 s timeout; timezone/locale used as provisional value until IP resolves.
- Language now follows detected country (TW→zh-Hant, BR→pt, MX→es, …) via COUNTRY_LANG,
  with the manual language switcher still overriding (and persisting). Added a country
  picker + "📍 country" indicator + per-match "Watch" row.

**Schedule source decision (user):** switch source of truth to the official FIFA
JSON calendar API. Note: `api.fifa.com` was unreachable from the local fetch tool this
session; the cloud daily routine should attempt it (and free-text Wikipedia must be
fetched ONE GROUP AT A TIME with explicit match numbers — bulk summaries jumble order).

## 2026-06-15 (run 3) — Full non-Eastern sweep (partial); web-extraction unreliable

**Goal:** verify all non-Eastern-venue kickoffs (Pacific / Central / Mexico) across
groups A, B, C, E (D/F/G already done).

**Reliability finding:** Wikipedia data pulled via WebFetch (free-text summary) is
NOT trustworthy for bulk correction — it jumbles match→time mapping. Evidence:
Group C extraction ordered match 14 (Brazil–Morocco) before match 13 (Haiti–Scotland),
contradicting official numbering; Group B returned Canada–Bosnia at 3 PM Toronto
(Eastern venue, no conversion) vs stored 8 PM — an impossible 5 h gap. Therefore only
**double-corroborated** changes were applied this run.

**Applied (2 sources agree — Wikipedia + NBC):**
- Match 4 — Mexico v South Korea: `Jun 18 23:00` → `Jun 18 21:00` ET (9 PM ET / 7 PM Mexico)
- Match 27 — Germany v Ivory Coast: `Jun 20 13:00` → `Jun 20 16:00` ET (4 PM ET) — upcoming match

**Single-source suspicions, NOT applied (need a clean structured source to confirm):**
- Match 1 — Mexico v South Africa: Wiki 1 PM Mexico = 15:00 ET vs stored 16:00 (played)
- Match 2 — South Korea v Czechia: Wiki 8 PM Mexico = 22:00 ET vs stored 19:00 (played)
- Match 26 — Ivory Coast v Ecuador: Wiki 7 PM EDT = 19:00 ET vs stored 20:00 (played)
- Match 16 — Brazil v Haiti: Wiki 8:30 PM EDT = 20:30 ET vs stored 21:00
- Group B / C kickoff times generally — extraction jumbled, re-verify from a clean source.
- Match 31 / 32 — still open from run 2.

**RECOMMENDATION:** Switch the source of truth to the official FIFA JSON calendar API
(returns exact UTC timestamps — no zone math, no summarizer jumbling) or a
user-provided authoritative schedule. Free-text WebFetch of Wikipedia is too lossy.

## 2026-06-15 (run 2) — Flagged Pacific/Mexico-venue kickoffs corrected

**Sources:** Wikipedia per-group pages D / F / J (kickoffs in venue-local time +
UTC offsets). Confirms ESPN is systematically wrong for evening Pacific & Mexico
venue games. Conversion to stored ET value: Pacific (PDT, UTC-7) +3h; Mexico
Central (UTC-6, no DST) +2h.

**Changes (stored ET value):**
- Match 19 — USA v Paraguay: `Jun 12 19:00` → `Jun 12 21:00` (6:00 PM PDT, Inglewood)
- Match 20 — Australia v Türkiye: `Jun 13 00:00` → `Jun 14 00:00` (9:00 PM PDT, Vancouver)
- Match 22 — Türkiye v Paraguay: `Jun 19 00:00` → `Jun 19 23:00` (8:00 PM PDT, Santa Clara)
- Match 34 — Tunisia v Japan: `Jun 20 00:00` → `Jun 21 00:00` (10:00 PM UTC-6, Monterrey/Guadalupe)
- Match 56 — Austria v Jordan: `Jun 16 00:00` → `Jun 17 00:00` (9:00 PM PDT, Santa Clara)

Also removed the static "Canada · Mexico · USA" hosts line from index.html (it was
the only un-localized text on the page).

**Newly spotted, NOT changed yet (need a clean second source — verify next run):**
- Match 31 — Netherlands v Japan: stored `Jun 14 19:00 ET`; Wikipedia extraction suggested 3:00 PM Central = 16:00 ET, but the source's zone label was garbled. Confirm.
- Match 32 — Sweden v Tunisia: Wikipedia shows a final score 5–1 (no score stored yet). Confirm before adding.

**Systemic risk:** ESPN is unreliable for ALL Pacific-venue kickoffs. A full sweep of
every Santa Clara / Inglewood / Vancouver / Seattle match across all 12 groups is
recommended (the daily routine should do this).

---

## 2026-06-15 — Group G corrected; data extracted to `matches.js`

**Sources checked:** Wikipedia `2026_FIFA_World_Cup_Group_G` (confirmed by Sky/NBC).
ESPN's June 15 Group G times were wrong by 8–9h (Pacific-venue timezone bug).

**Changes:**
- Match 37 — Belgium vs Egypt: `Jun 15 13:00 ET, Inglewood` → `Jun 15 15:00 ET, Seattle (Lumen Field)`
- Match 38 — Iran vs New Zealand: `Jun 15 00:00 ET, Inglewood` → `Jun 15 21:00 ET, Inglewood (SoFi)`
- Matches 39–42 (Jun 21 & 26): verified correct, no change.

**Refactor:** Fixture data moved out of `index.html` into `matches.js` (single source
of truth). Added `window.WC_LAST_VERIFIED` + a freshness line in the page footer.

**Still flagged for verification (suspected same ESPN bug — `00:00 ET` kickoffs):**
- Match 20 — Australia vs Türkiye (Group D)
- Match 22 — Türkiye vs Paraguay (Group D)
- Match 34 — Tunisia vs Japan (Group F)
- Match 56 — Austria vs Jordan (Group J)
